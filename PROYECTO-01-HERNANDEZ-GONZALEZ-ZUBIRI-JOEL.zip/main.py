#USUARIO
user="Admin"
password="123"

usuarios=[["Javier","123"],["EMTECHmembers","123"]]

usr_inpt=input("ingresa el usuario: ")
pass_inp=input("ingresa la contraseña: ")
for user in usuarios:
 
    print("bienvenido a Lifestore")

#PRIMERA PARTE
import functools
from lifestore_file import lifestore_products, lifestore_sales, lifestore_searches




# Comparison function for custom sorting according to decreasing values of second element of list items
def compare1(item1, item2):
    return item2[1] - item1[1]


# Comparison function for custom sorting according to increasing values of second element of list items
def compare2(item1, item2):
    return item1[1] - item2[1]


# Store the total number of products in the dataset
totalProducts = len(lifestore_products)

# The following would store the total number of searches and total sales of each individual product
searchesDone = []
salesDone = []

# Initialize the above lists with [product_id, 0]
for i in range(totalProducts):
    searchesDone.append([i + 1, 0])
    salesDone.append([i + 1, 0])

# Iterate through the lifestore_searches list and increment the search done for the corresponding product_id
for searches in lifestore_searches:
    productId = searches[1] - 1
    searchesDone[productId] = [productId + 1, searchesDone[productId][1] + 1]

# Iterate through the lifestore_sales list and increment the sale done for the corresponding product_id
for sales in lifestore_sales:
    productId = sales[1] - 1
    salesDone[productId] = [productId + 1, salesDone[productId][1] + 1]

# Find the top 50 products with highest sales
top50Sales = sorted(salesDone, key=functools.cmp_to_key(compare1))[:50]

# Find the top 100 products with highest searches
top100Searches = sorted(searchesDone, key=functools.cmp_to_key(compare1))[:100]

# Print the result for the top 50 sales
print("")
print("Top 50 sales: (ID ---> Sales)")
print("")
for prod in top50Sales:
    print("{0} ---> {1} sales".format(prod[0], prod[1]))

# Print the result for the top 100 searches
print("")
print("Top 100 searches: (ID ---> Searches)")
print("")
for prod in top100Searches:
    print("{0} ---> {1} searches".format(prod[0], prod[1]))

# Find the 50 products with lowest sales
lowest50Sales = sorted(salesDone, key=functools.cmp_to_key(compare2))[:50]

# Find the 100 products with lowest searches
lowest100Searches = sorted(
    searchesDone, key=functools.cmp_to_key(compare2))[:100]

# Print the result for the 50 lowest sales
print("50 Lowest sales: (ID ---> Sales)")
print("")
for prod in lowest50Sales:
    print("{0} ---> {1} sales".format(prod[0], prod[1]))

# Print the result for the 100 lowest searches
print("")
print("100 Loweset searches: (ID ---> Searches)")
print("")
for prod in lowest100Searches:
    print("{0} ---> {1} searches".format(prod[0], prod[1]))

#SEGUNDA PARTE
#importing lifestore_file
import lifestore_file as ls

#retrieving the review numbers for filtering the best and worst items as a set so they don't contain duplicates
review_number = set([i[2] for i in ls.lifestore_sales])

#retrieving the best and worst sales from the obtained review numbers
best_reviewed_sales = [
    i for i in ls.lifestore_sales if i[2] == max(review_number)
]
worst_reviewd_sales = [
    i for i in ls.lifestore_sales if i[2] == min(review_number)
]

#appending the product names alone from 'lifestore_products' with respect to the corresponding 'id_product' which acts likes
#a foreign key to both 'lifestore_products' and 'lifestore_sales'
best_reviewed_items = [[i[1] for i in ls.lifestore_products if x[1] == i[0]]
                       for x in best_reviewed_sales]
worst_reviewed_items = [[i[1] for i in ls.lifestore_products if x[1] == i[0]]
                        for x in worst_reviewd_sales]

#removing duplicates in both the best and worst items list
best_items = []
for i in best_reviewed_items:
    if i not in best_items:
        best_items.append(i)
worst_items = []
for j in worst_reviewed_items:
    if j not in worst_items:
        worst_items.append(j)

#displaying maximum 20 items as asked by the end user
print("Items with best ratings which is " + str(max(review_number)) +
      " are  :")
print(best_items[:20])
print("\n")
print("Items with worst ratings which is " + str(min(review_number)) +
      " are  :")
print(worst_items[:20])


#TERCERA PARTE
def totalRevenue():
    for i in lifestore_sale:
        for j in lifestore_product:
            if i[1] == j[0]:
                totalRev += j[2] * i[2]
    return totalRev


def annualTotal():
    annualTotal = {}
    s = list(set(lifestore_sale[3][6:]))
    for i in s:
        for j in lifestore_sale:
            for k in lifestore_product:
                if i in j[3] and j[4] == 0 and k[0] == j[1]:
                    annualTotal[i] += j[2] * k[2]
    return annualTotal


def averageMonthlySale():
    averageMonthlySale = {}
    y = list(set(lifestore_sale[3][3:]))
    for i in s:
        c = 0
        for j in lifestore_sale:
            for k in lifestore_product:
                if i in j[3] and j[4] == 0 and k[0] == j[1]:
                    averageMonthlySale[i] += j[2] * k[2]
                    c += 1
        averageMonthlySale[i] /= c
    return averageMonthlySale


def monthTotal():
    monthTotal = {}
    s = list(set(lifestore_sale[3][3:]))
    for i in s:
        for j in lifestore_sale:
            for k in lifestore_product:
                if i in j[3] and j[4] == 0 and k[0] == j[1]:
                    monthTotal[i] += j[2] * k[2]
    return monthTotal


def mostSalePerYear():
    mostSalePerYear = {}
    s = list(set(lifestore_sale[3][3:]))
    for i in s:
        mostSalePerYear[i] = 0
    for i in s:
        monthTotal = 0
        for j in lifestore_sale:
            for k in lifestore_product:
                if i in j[3] and j[4] == 0 and k[0] == j[1]:
                    monthTotal += j[2] * k[2]
        if mostSalePerYear[i] < monthTotal:
            mostSalePerYear[i] = monthTotal
    return mostSalePerYear
